# Tra cứu Call Off 5G

Web app tra cứu thông số trạm 5G (sector, azimuth, tilt, độ cao AAU, tọa độ GPS...) từ file Excel Call Off. Chạy hoàn toàn trên trình duyệt (không cần server, không cần backend) — mở được trên điện thoại, laptop, bất kỳ thiết bị nào có trình duyệt.

File Excel mặc định nằm ở `data/TH_Calloff_5G.xlsx` trong repo — trang **tự động tải file này khi mở lên**, không cần bấm gì. Muốn dùng file khác (mới hơn, hoặc của trạm/tỉnh khác), bấm **"Tải file Excel"** để chọn file trên máy — file đó sẽ được ưu tiên dùng cho những lần mở sau (lưu tạm trên trình duyệt của bạn, không ảnh hưởng file mặc định trong repo). Bấm nút mũi tên vòng (⟲) cạnh đó để quay lại dùng file mặc định.

## Tính năng

- Tải lên file Excel (`.xlsx`) chứa 2 sheet **"DS TRẠM"** và **"CALL OFF"**
- Gõ mã trạm → gợi ý tự động (autocomplete) khi đang gõ
- Hiện toàn bộ sector của trạm (`_1`, `_2`, `_3`...) kèm góc Azimuth, độ cao AAU (so với chân cột / mặt đất), Tilt cơ, Tilt điện, độ cao treo GPS
- Hiện thông tin từ sheet "DS TRẠM" (nhân viên phụ trách, SĐT, loại cột, độ cao cột...)
- Tự nhận diện cột tọa độ (nếu file có thêm cột tọa độ X/Y, vĩ độ/kinh độ...) → tự ghép thành `lat, lon`, có nút **Sao chép** và nút **Mở Google Maps**
- **Tự động hiển thị cột mới**: nếu sau này bạn thêm cột vào sheet CALL OFF (ví dụ thêm cột tọa độ), không cần sửa code — bảng chi tiết sẽ tự hiện thêm cột đó
- Lưu tạm file đã tải lên trình duyệt (localStorage) để lần sau mở lại không cần tải lại file
- Kéo-thả file trực tiếp vào trang cũng được
- **Tự động tải file mặc định** (`data/TH_Calloff_5G.xlsx`) ngay khi mở trang, không cần thao tác gì
- **Tự dò cấu trúc file**: nhận biết được cả sheet có 1 dòng tiêu đề lẫn sheet có nhiều dòng tiêu đề (kiểu merge cell) — nên đổi file mới, kể cả khi cấu trúc cột hơi khác, vẫn thường chạy được ngay

## Cách dùng ngay (không cần cài gì)

Mở file `index.html` bằng trình duyệt bất kỳ (double-click là được), sau đó bấm **"Tải file Excel"** và chọn file `.xlsx` của bạn.

## Đưa lên GitHub Pages (để truy cập bằng link, mọi thiết bị)

```bash
# 1. Tạo repo mới trên GitHub (qua giao diện web), ví dụ tên "calloff-5g-lookup"
# 2. Trong thư mục này:
git init
git add .
git commit -m "Init: Call Off 5G lookup tool"
git branch -M main
git remote add origin https://github.com/<TÊN_GITHUB_CỦA_BẠN>/calloff-5g-lookup.git
git push -u origin main
```

Sau đó vào repo trên GitHub → **Settings → Pages** → chọn **Branch: main / (root)** → Save.
Sau khoảng 1 phút, trang sẽ chạy tại:

```
https://<TÊN_GITHUB_CỦA_BẠN>.github.io/calloff-5g-lookup/
```

Mở link này trên điện thoại, laptop — đều dùng được. Mỗi lần vào, bạn (hoặc đồng nghiệp) tự tải file Excel lên là tra cứu được ngay.

## Cập nhật file Excel mặc định

Muốn đổi dữ liệu mặc định cho tất cả mọi người dùng chung (không phải chỉ trên máy bạn), thay file `data/TH_Calloff_5G.xlsx` trong repo bằng file mới (giữ nguyên tên file), rồi commit lên GitHub là xong — không cần sửa code.

Trên GitHub: vào thư mục `data/` → bấm vào file `TH_Calloff_5G.xlsx` → biểu tượng thùng rác để xoá, rồi **"Add file" → "Upload files"** đưa file mới lên với đúng tên đó. Hoặc dùng "Upload files" và ghi đè trực tiếp.

## Khi file Excel thay đổi cấu trúc

Cấu hình đọc file nằm ở đầu file `index.html`, trong object `CONFIG`. Số dòng tiêu đề của mỗi sheet được **tự động dò** (hỗ trợ cả kiểu 1 dòng tiêu đề lẫn kiểu nhiều dòng có merge cell), nên phần lớn thay đổi nhỏ không cần sửa code:

```js
const CONFIG = {
  sheetTram: "DS TRẠM",       // tên sheet thông tin trạm
  sheetCallOff: "CALL OFF",   // tên sheet call off 5G
  defaultFileUrl: "./data/TH_Calloff_5G.xlsx", // đường dẫn file mặc định trong repo
  ...
};
```

- **Thêm cột mới vào sheet CALL OFF hoặc DS TRẠM** (ví dụ thêm cột tọa độ): không cần sửa gì — cột mới tự hiện trong bảng "Xem bảng chi tiết đầy đủ" / trong thông tin trạm, và nếu là cột tọa độ thì tự động được nhận diện để ghép vào ô tọa độ + nút Google Maps (nhận diện qua các từ khóa: "tọa độ x/y", "Long/Lat", "vĩ độ", "kinh độ", "latitude/longitude").
- **Đổi tên sheet**: sửa `sheetTram` / `sheetCallOff` trong `CONFIG` cho khớp.
- **Tọa độ bằng 0 (0,0)** được coi là "chưa có dữ liệu" và sẽ không hiện thẻ tọa độ, để tránh nhầm sang khu vực khác trên bản đồ.

## Công nghệ dùng

- HTML/CSS/JavaScript thuần, không cần build
- [SheetJS (xlsx.js)](https://sheetjs.com/) để đọc file Excel ngay trên trình duyệt, tải qua CDN

## Cấu trúc thư mục

```
index.html               — toàn bộ ứng dụng (giao diện + logic)
data/TH_Calloff_5G.xlsx  — file Excel mặc định, tự tải khi mở trang
README.md                — file này
```
